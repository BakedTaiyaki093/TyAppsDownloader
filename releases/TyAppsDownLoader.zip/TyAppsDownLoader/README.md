dirct.txtには保存先のフォルダを指定してください。
created by BakedTaiyaki093 and Copilot
I don't have any its license, but Don't copy code! 